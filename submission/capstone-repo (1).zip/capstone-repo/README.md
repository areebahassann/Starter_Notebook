# Capstone — Ranking Signal Analysis

This repo is the full deliverable scaffold for the capstone: a reproducible notebook
pipeline + a deployed research paper, built on the FlyRank ML Internship dataset.

**Lane chosen: Ranking Signal Analysis** — studying which safe content/search
signals are associated with visibility, clicks, engagement, or movement, and
turning that into an evidence-backed signal report + recommendations.
(Chosen because it's the best-bounded lane: no sparse-label risk like AI-referral,
no need for clean future-window labels like momentum prediction — good fit for a
one-pass capstone.)

## What's already built for you

- `work/capstone_notebook.ipynb` — full pipeline: HF auth, DuckDB aggregation over
  `hf://`, feature engineering, label definition, grouped/time-aware split, leakage
  checks, baseline vs model, signal report generation. Every cell has real code —
  nothing is pseudocode — but it has **not been run**, because this environment has
  no network access and no Hugging Face token. You need to run it yourself.
- `paper/index.html` — the deployed research paper, all 8 required sections,
  fully designed and written except for the numeric results, charts, and specific
  signal findings, which are marked `[[FILL: ...]]`. Once you run the notebook you
  paste in the real numbers (instructions inside the notebook's last cell).
- `submission/paper_url.txt` — placeholder. **You must overwrite this** with the
  real deployed URL before this counts as submitted — see below.
- `work/capstone_report.md` — the rubric-format report (the 8-section template you
  uploaded), filled in to match everything above. Same deal: `[[FILL: ...]]` marks
  every spot that needs your real run numbers.
- `work/` — put every other assignment notebook here too (whatever you already
  have from earlier in the course). I only had context for the capstone itself.

## What you still have to do (can't be done from here — no network/creds)

1. **Get a Hugging Face read token** for the gated warehouse dataset (2-minute
   access, per the dataset card).
2. **Run `work/capstone_notebook.ipynb` top to bottom** with that token set as
   `HF_TOKEN` in your environment. It will print/save the numbers, tables, and
   chart images the paper needs, into `work/outputs/`.
3. **Fill the `[[FILL: ...]]` placeholders** in `paper/index.html` **and**
   `work/capstone_report.md` with those real numbers (all clearly marked, search
   each file for `FILL`).
4. **Deploy `paper/index.html`.** Easiest: push this repo to GitHub, enable
   GitHub Pages on the `paper/` folder (or move `index.html` to repo root / a
   `docs/` folder, whichever your Pages setup wants), get the live URL.
5. **Put that exact URL, and only that URL, as a single line in
   `submission/paper_url.txt`.** This file is how the paper is found — nothing
   else you submit matters if this is wrong or missing.
6. Double check the public-safety rule before publishing: no client names, no
   real domains/URLs from the dataset, no private queries, no credentials, no
   raw exports, and no claim that this proves causal Google algorithm impact.
   The notebook and paper template are already written to respect this (signals
   are referred to generically, e.g. "title length", "content depth bucket" —
   not by client or URL), but review your filled-in numbers/quotes before you
   push, since I can't see the real data.

## Repo layout

```
work/
  capstone_notebook.ipynb   <- run this with your HF token
  outputs/                  <- created when you run the notebook (charts, tables)
  (add your other assignment notebooks here)
paper/
  index.html                <- the deployed research paper (fill placeholders, then deploy)
submission/
  paper_url.txt             <- put the ONE deployed URL here, nothing else
```
