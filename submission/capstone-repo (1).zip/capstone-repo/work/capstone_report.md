# Capstone Report — Ranking Signal Analysis

- **Author:** [[FILL: your name]]
- **Lane:** Ranking Signal Analysis
- **Repo:** [[FILL: your repo URL]]
- **Date:** [[FILL: submission date]]

## 1. Problem framing

**Decision supported:** which content/structural signal an editorial reviewer should check
*first* when a page is underperforming its search position — a triage list, not an
auto-apply fix.

**Unit of analysis:** page (one row per page, aggregated over the date window — not
per-query, per-click, or per-day, to avoid noisy single-day metrics).

**Output:** a ranked signal report — each candidate signal (title length, meta description
length, word count, heading count, internal link count, schema markup presence, content age)
ranked by its association strength with a page's CTR-gap, plus a short human-readable finding
and action per top signal.

**Action a human takes:** an editor pulls the ranked list, opens the pages flagged as
under-performing on a high-importance signal, and reviews/fixes that specific element first
instead of guessing across dozens of possible causes.

**Cost of a wrong call:** low-to-medium — a wrong priority order wastes editor review time on
a page that wasn't actually the highest-leverage fix, but it never auto-publishes or
auto-deletes anything, since the output is a ranked review list, not an autonomous action.

**Why data/ML helps:** with hundreds of pages and half a dozen+ candidate signals, eyeballing
which signal actually correlates with under-performance doesn't scale — a model trained to
predict CTR-gap from these signals, then inspected for feature importance, turns "which of
these matters most, on average, across the whole warehouse" into a rankable, testable
question instead of a guess.

## 2. Data safety

**Data used:** the FlyRank ML Internship warehouse pages + metrics tables, joined on
`page_id`, scoped to [[FILL: your DATE_START–DATE_END]].

**Columns deliberately excluded:**
- Any client/domain-identifying columns — nothing beyond an internal `page_id` used only for
  grouping (never as a feature).
- Any pre-computed trend/label-adjacent fields (e.g. `trend_direction`, `trend_pct`, or
  anything computed *from* the same metrics window as the label) — these would leak the
  label back into the features.
- Raw query text / private query-level data — not needed at page-level aggregation.

**Leakage risks considered:**
- `page_id` is used only to group the train/test split (so a page never appears on both
  sides), never fed to the model as a feature.
- The label (CTR-gap) and features are computed from disjoint aspects of the data — features
  are structural/content properties of the page, not derived from the same click/impression
  numbers used to build the label — but see the leakage check in the notebook (§5) which
  explicitly verifies zero overlapping `page_id`s between train and test before scoring.
- The time-aware split (train on the earlier ~80% of the window, test on the later ~20%)
  guards against a signal that only "worked" during a specific sub-period leaking a
  falsely-strong association.

**Confirmation:** nothing client-identifying appears anywhere in `work/` — the notebook only
ever prints/saves aggregated, generic column names and counts, never raw URLs, domains, or
query strings.

## 3. Baseline

**Baseline:** a median-CTR-gap `DummyRegressor` — predicts the training-set median CTR-gap
for every page, regardless of its features.

**Why it's fair:** it's evaluated on the exact same held-out time split and the exact same
metrics (MAE, R²) as the real model — so any improvement the model shows is improvement over
"just guess the typical page," not an artifact of an easier test set.

**Baseline numbers:** [[FILL: MAE / R² from outputs/model_vs_baseline.csv, baseline row]]

## 4. Model / analysis

**Method:** gradient-boosted regression (`GradientBoostingRegressor`, scikit-learn) — chosen
because it handles the mix of count-like and binary features here without manual scaling, and
its `feature_importances_` gives a direct, inspectable ranking of which signals it actually
used — which is the deliverable for this lane, not just the prediction itself.

**Feature list used:** [[FILL: from notebook FEATURES list after running — e.g. title
length, meta description length, word count, heading count, internal link count, has schema
markup, content age (days)]].

**Left out on purpose:** `page_id` (grouping only), raw click/impression counts (these define
the label — including them as features would be circular), and anything domain/client-level.

**Target/proxy definition (one sentence):** CTR-gap — a page's actual click-through rate
minus the median CTR observed across all pages at that same rounded average search position
over the window, so the target already controls for "of course a #1 result gets more clicks
than a #9 result."

## 5. Evaluation

**Split:** time-aware (train = earlier ~80% of the date window, test = later ~20%) **and**
grouped by `page_id`, so no page's rows appear on both sides — chosen over a random split
because it validates the way the model would actually be used: trained on past data, checked
against what happens next, not just a random shuffle that lets easy repeat-pages leak signal
across the split.

**Base rate:** this is a regression task (continuous CTR-gap), not classification, so there's
no majority-class base rate — the honest "did we beat guessing" comparison is model MAE/R²
vs. the median-baseline MAE/R² above, on the identical split.

**Model vs. baseline (same split, same metric):**

| | MAE | R² |
|---|---|---|
| Baseline (median) | [[FILL]] | [[FILL]] |
| Model (gradient boosted) | [[FILL]] | [[FILL]] |

**Error analysis:** [[FILL: 2-3 sentences — e.g. which kind of page the model is most wrong
about (very new pages? very high position pages?), and whether errors are roughly symmetric
or skewed in one direction]].

## 6. Interpretation

**What the model found, in plain words:** [[FILL: top 2-3 signals by importance from
outputs/signal_importances.csv, described in plain language — e.g. "pages with shorter meta
descriptions tend to under-capture clicks relative to their position more than any other
signal we tested"]].

**Surprises / negative results:** [[FILL: note any signal that came back near-zero
importance despite expecting it to matter — a real "no effect" finding, stated as such, not
hidden]].

## 7. Recommendation

Ranked actions an editor would use tomorrow (see `paper/index.html` §6 for the deployed
version of this list):

1. [[FILL: signal #1 — finding + concrete review action]]
2. [[FILL: signal #2 — finding + concrete review action]]
3. [[FILL: signal #3 — finding + concrete review action]]

**Confidence:** directional and decision-support only — this ranks *where to look first*,
it does not predict how much a fix will move a page's numbers, and it makes no claim about
Google's ranking algorithm.

**Limits:** observational data, one date window, correlational associations — see
`paper/index.html` §5 (Limitations & honest framing) for the full statement.

## 8. Reproducibility

**Fresh-clone re-run:**
```bash
git clone [[FILL: your repo URL]]
cd [[FILL: repo folder]]
pip install -r requirements.txt   # duckdb, pandas, numpy, scikit-learn, matplotlib, jupyter
export HF_TOKEN=your_hf_read_token
jupyter nbconvert --to notebook --execute work/capstone_notebook.ipynb
```

**Random seed:** `random_state=42` (set once, in the `GradientBoostingRegressor` call in
`work/capstone_notebook.ipynb` §6 — same seed reproduces the same model/importances).

**Environment:** [[FILL: paste `pip freeze` highlights or a requirements.txt diff once you've
actually run this — duckdb / pandas / scikit-learn / matplotlib versions]].

---

> **Claims checklist before submitting:** observed / measured / directional / decision-support
> language everywhere · no causal claims without an experiment or causal design · no
> "predicted Google's algorithm" · no client-identifying details · numbers in this report
> match a fresh re-run.
>
> [[FILL: once you've run the notebook and filled every FILL above, re-read this report
> against that checklist one more time before you push.]]
